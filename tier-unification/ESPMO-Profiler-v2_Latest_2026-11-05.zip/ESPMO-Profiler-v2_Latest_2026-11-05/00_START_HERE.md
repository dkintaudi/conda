# ESPMO Project Profiler — latest set (v2, built 2026-11-05)

Source: `dkintaudi/conda`, branch `claude/festive-keller-ncjzed`, commit 1611941 ("Q22 (data): add exclusions note").
This replaces the June `ESPMO-Toolset-v01_3-TIER-UNIFIED.zip`, which has an older Profiler.

| Folder | Contents |
|---|---|
| 01_Tools | Project-Profiler.html (v2), Autogenerate.html (v1.2), Minutes-to-Deliverables.html (v1.2). Open in any browser; no install needed. |
| 02_Documentation | Implementation notes, tier-unification spec, 27-question build spec, security-gating build order, Autogenerate TRT/scope notes, T-shirt breakdown fidelity report (.md + .docx), rules-gen and stress-test READMEs |
| 03_Reference_Workbooks | ESPMO-Rules-v01.04 (current rules), EDD T-shirt breakdown, template paths, portfolio tiers |
| 04_Sample_Inputs | Sample Profiler exports (Standard and Mini) |
| 05_Security_Schedule | IDP security task template, generated schedule, README |

Recent Profiler changes (Oct–Nov 2026): Q13 scope reworked (single-select, IT system / Business process / Service-Capability),
'Not sure' conservatively triggers on Q13/Q27/Q28/Q31–Q33, Q27 security wording and Cybersecurity engagement,
Q22 sensitive data → PIA, the four PAL questions shown as one block, and the Documents sheet now lists only the artifacts
the answers actually trigger (7 consolidated templates).

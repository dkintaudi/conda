# Template QA Checks

This folder contains a small Python validation script for the Auto Generator templates and filled examples.

Run it before repackaging or distributing the toolset:

```bash
python validate_templates.py --package-dir .
```

It checks for:
- blank table rows that make generated documents look broken;
- spaced template placeholders such as `{# risks}` or `{/ risks}`;
- risk response/mitigation cells that were accidentally shortened into tiny placeholder responses.

The script uses only the Python standard library.

#!/usr/bin/env python3
"""
ESPMO template QA check.

Purpose:
  Verifies Word template/example files so generated artifacts do not look broken.

Checks:
  1. No empty table rows.
  2. No spaced placeholders such as {# risks}, {/ risks}, or { risk }.
  3. Risk response/mitigation cells are not reduced to tiny placeholder responses.

Usage examples:
  python validate_templates.py --package-dir .
  python validate_templates.py --package-dir ../User-Pack
  python validate_templates.py --package-dir ../User-Pack --strict

This script uses only the Python standard library.
"""
from __future__ import annotations

import argparse
import io
import re
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple
import xml.etree.ElementTree as ET

NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
PLACEHOLDER_RE = re.compile(r"\{[^{}]{1,80}\}")
WORD_RE = re.compile(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)?")

@dataclass
class Finding:
    severity: str
    path: str
    detail: str


def clean_text(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def cell_text(tc: ET.Element) -> str:
    return clean_text("".join(t.text or "" for t in tc.findall(".//w:t", NS)))


def para_text(p: ET.Element) -> str:
    return clean_text("".join(t.text or "" for t in p.findall(".//w:t", NS)))


def docx_tables_and_text(data: bytes) -> Tuple[List[List[List[str]]], str]:
    with zipfile.ZipFile(io.BytesIO(data)) as dz:
        xml = dz.read("word/document.xml")
    root = ET.fromstring(xml)
    all_text = clean_text(" ".join(para_text(p) for p in root.findall(".//w:p", NS)))
    tables: List[List[List[str]]] = []
    for tbl in root.findall(".//w:tbl", NS):
        rows: List[List[str]] = []
        for tr in tbl.findall("./w:tr", NS):
            rows.append([cell_text(tc) for tc in tr.findall("./w:tc", NS)])
        tables.append(rows)
    return tables, all_text


def iter_files_in_zip(zip_bytes: bytes, prefix: str, depth: int = 0) -> Iterable[Tuple[str, bytes]]:
    if depth > 4:
        return
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = f"{prefix}/{info.filename}" if prefix else info.filename
            data = z.read(info.filename)
            lower = info.filename.lower()
            if lower.endswith(".docx"):
                yield name, data
            elif lower.endswith(".zip"):
                yield from iter_files_in_zip(data, name, depth + 1)


def iter_docx(package_dir: Path) -> Iterable[Tuple[str, bytes]]:
    for path in sorted(package_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(package_dir).as_posix()
        lower = path.name.lower()
        if lower.endswith(".docx"):
            yield rel, path.read_bytes()
        elif lower.endswith(".zip"):
            yield from iter_files_in_zip(path.read_bytes(), rel)


def placeholder_findings(path: str, text: str) -> List[Finding]:
    findings: List[Finding] = []
    for ph in PLACEHOLDER_RE.findall(text):
        inner = ph[1:-1]
        if inner != inner.strip() or re.search(r"\s", inner):
            findings.append(Finding("ERROR", path, f"Spaced placeholder detected: {ph}"))
    return findings


def blank_row_findings(path: str, tables: List[List[List[str]]]) -> List[Finding]:
    findings: List[Finding] = []
    for ti, rows in enumerate(tables, start=1):
        for ri, row in enumerate(rows, start=1):
            if row and all(not c.strip() for c in row):
                findings.append(Finding("ERROR", path, f"Blank table row: table {ti}, row {ri}"))
    return findings


def risk_response_findings(path: str, tables: List[List[List[str]]], min_words: int, min_chars: int) -> List[Finding]:
    findings: List[Finding] = []
    for ti, rows in enumerate(tables, start=1):
        if not rows:
            continue
        header = [c.lower() for c in rows[0]]
        risk_cols = [i for i, c in enumerate(header) if "risk" in c]
        response_cols = [i for i, c in enumerate(header) if any(k in c for k in ["response", "mitigation"])]
        if not risk_cols or not response_cols:
            continue
        risk_i, response_i = risk_cols[0], response_cols[0]
        for ri, row in enumerate(rows[1:], start=2):
            if max(risk_i, response_i) >= len(row):
                continue
            risk, response = row[risk_i].strip(), row[response_i].strip()
            if not risk:
                continue
            # Template files legitimately contain placeholder-only risk rows such as
            # {risk} / {response}. Validate placeholder spacing separately, but do
            # not treat placeholder tokens as shortened business responses.
            if "{" in risk or "{" in response:
                continue
            words = WORD_RE.findall(response)
            if not response:
                findings.append(Finding("ERROR", path, f"Missing risk response: table {ti}, row {ri}"))
            elif len(words) < min_words or len(response) < min_chars:
                findings.append(Finding("ERROR", path, f"Risk response too short: table {ti}, row {ri}: {response!r}"))
    return findings


def run(package_dir: Path, min_words: int, min_chars: int, expected_min_docx: int = 0) -> List[Finding]:
    findings: List[Finding] = []
    scanned = 0
    for path, data in iter_docx(package_dir):
        scanned += 1
        try:
            tables, text = docx_tables_and_text(data)
        except Exception as exc:
            findings.append(Finding("ERROR", path, f"Could not parse DOCX: {exc}"))
            continue
        findings.extend(placeholder_findings(path, text))
        findings.extend(blank_row_findings(path, tables))
        findings.extend(risk_response_findings(path, tables, min_words=min_words, min_chars=min_chars))
    if scanned == 0:
        findings.append(Finding("ERROR", str(package_dir),
            "No DOCX files found to validate. Point --package-dir at the package root "
            "(the folder containing 02_Templates_and_Reference.zip)."))
    elif scanned < expected_min_docx:
        # Guard against a misdirected scan silently passing: if we found fewer DOCX
        # than the package is known to contain, treat it as a failure rather than a pass.
        findings.append(Finding("ERROR", str(package_dir),
            f"Found only {scanned} DOCX file(s) but expected at least {expected_min_docx}. "
            "Likely scanning the wrong folder; check --package-dir."))
    else:
        print(f"Scanned {scanned} DOCX file(s).")
    return findings


PACKAGE_MARKER = "02_Templates_and_Reference.zip"


def find_package_root() -> Tuple[Path, bool]:
    """Locate the package root by walking up from this script looking for the
    marker file the package always ships (02_Templates_and_Reference.zip).

    Returns (path, located). `located` is True when the marker was found, so the
    caller can decide whether to apply the package-size floor. Falls back to the
    current working directory when no marker is found anywhere up the tree, so a
    stray copy of this script still scans something sensible instead of erroring
    on an unrelated grandparent folder.
    """
    here = Path(__file__).resolve().parent
    # Walk this dir and every ancestor; the marker lives at the package root.
    for cand in (here, *here.parents):
        if (cand / PACKAGE_MARKER).is_file():
            return cand, True
    return Path.cwd().resolve(), False


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate ESPMO DOCX templates and filled examples.")
    # Self-locating default: find the package root by its marker file rather than
    # assuming a fixed depth, so the validator works no matter where the script is
    # run from and even if it is moved within the tree. Falls back to CWD.
    default_package_dir, default_located = find_package_root()
    parser.add_argument("--package-dir", default=str(default_package_dir), help="Folder containing the User-Pack/Developer-Pack files or nested ZIPs. Defaults to the auto-located package root.")
    parser.add_argument("--min-risk-response-words", type=int, default=7)
    parser.add_argument("--min-risk-response-chars", type=int, default=45)
    parser.add_argument("--expected-min-docx", type=int, default=None,
        help="Fail if fewer than this many DOCX files are found (guards against a misdirected scan). "
             "Defaults to 17 only when scanning the auto-located package root; off when you pass an explicit --package-dir.")
    args = parser.parse_args(argv)

    package_dir = Path(args.package_dir).resolve()
    # The floor is a safety net for the default full-package run. Apply it only
    # when we are scanning the auto-located package root (marker found). If the
    # user deliberately points --package-dir at a narrower folder, or the root
    # could not be auto-located, trust the scan and don't impose the package
    # count — unless they explicitly set --expected-min-docx themselves.
    on_located_root = default_located and package_dir == default_package_dir.resolve()
    if args.expected_min_docx is not None:
        expected_min_docx = args.expected_min_docx
    elif on_located_root:
        expected_min_docx = 17  # v01.2 ships 17 DOCX across the package + nested zips
    else:
        expected_min_docx = 0
    findings = run(package_dir, args.min_risk_response_words, args.min_risk_response_chars, expected_min_docx)
    if findings:
        print("\nTemplate QA findings:")
        for f in findings:
            print(f"[{f.severity}] {f.path} — {f.detail}")
        return 1
    print("Template QA passed: placeholders, table rows, and risk responses look clean.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

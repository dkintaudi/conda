# v01.06 — Profiler TRT Recommendation Deck Correction

Updated `01_Tools_Self_Contained/Project-Profiler.html` so the Profiler PowerPoint export creates a draft TRT/DCT recommendation deck instead of a generic Profiler summary presentation.

## Changes
- Reframed Save as PowerPoint output into the standard TRT/DCT deck structure: title, Background and Request, TRT Discussion, Scope of Work, Requirements Needed, and DCT Outcome.
- Preserved Profiler answer text and field inventory as backup slides, not as the main deck.
- Added source labeling so generated content is clearly tied to Profiler answer text, Profiler rules, and reviewer confirmation.
- Updated filename to `_Draft-TRT-Recommendation-deck.pptx`.
- Left Autogenerate unchanged.

## Validation
- JavaScript syntax check passed.
- Sample draft TRT deck generated successfully.
- PPTX package integrity check passed.
- Autogenerate hash remained unchanged from the v01.05 package.

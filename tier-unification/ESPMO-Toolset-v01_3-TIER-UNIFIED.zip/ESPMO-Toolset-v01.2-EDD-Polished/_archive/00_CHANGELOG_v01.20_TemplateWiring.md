# Changelog — v01.20  (Template Wiring Pass)

Builds on v01.19f. Governance model is unchanged (Mini / Standard / Targeted;
V-C = Value − avgComplexity×2.5; cutlines 60/80; govTier overlay; Optimal stays removed).
This release is **wiring only** — no scoring, banding, or gate logic was touched.

## Goal
Wire the templates so Autogenerate fills almost everything, leaving Copilot/PM only
signatures + funding source.

## What changed (Autogenerate.html)

1. **TRT roll-up counts wired — `doc_count` / `pmo_count` / `tarc_count`.**
   These three scalars on the TRT Recommendation template are now derived from the
   Profiler's triggered-artifact list rather than left empty. Each Profiler artifact
   carries an owner in its Assist/Advise column; we count total owned artifacts
   (`doc_count`), PMO-owned (`pmo_count`), and TARC-routed including "TARC → …" forms
   (`tarc_count`). New helper `artifactOwnerCounts(profileBuild)`. Injection happens in
   `buildData`, scoped to the TRT template, and only fills a placeholder that the
   template actually declares AND that is still empty — so an explicit figure stated in
   a TRT memo's prose still wins (fill order preserved: Profiler/TRT prose → TRT-derived
   roll-up → boilerplate → [PM TO COMPLETE]). Closes the 3 "derivable" gaps.

2. **Profiler "Artifacts" sheet is now read.** `parseHumanFacingProfiler` previously
   recognized only "Engagement Matrix" / "Documents" sheets. Current Profiler exports
   carry their triggered artifacts on an **Artifacts** sheet
   (`Artifact | Assist / Advise | Timing | Tier | Trigger`). That sheet is now parsed,
   with the owner preserved on each row's `assist` field. Without this, the triggered
   list was empty and the counts above had nothing to count.

3. **`addTemplate` banner heuristic made path-aware (`headerKnown` flag).** The
   `.+&.+` section-banner heuristic (which correctly drops "Initiation & Baseline" on
   the Engagement-Matrix/Documents paths, where names and headers share a column) was
   wrongly dropping real artifacts containing an ampersand — e.g. "C&A Package",
   "Test Plan & Test Cases", "Vulnerability Scan & Pen Test", "Vendor SOW & Contract
   Oversight", "Operations, Support & M&O Plan". On the Artifacts path, section headers
   are already separated by a blank Assist/Advise owner cell, so the ampersand heuristic
   is now skipped there (`headerKnown=true`). The legacy paths are unchanged.

4. **Version marker → v01.20.**

## Confirmed unchanged / verified-correct (no code change needed)
- **Gap reporter is already loop-aware.** `05_CRAID_Log`'s `{issue}` is a child of
  `{#issues}`; an empty issues loop at charter time is correct and the reporter does not
  surface it as a scalar gap (the v01.12 fix is intact and preserved).
- **The 5 true-manual fields stay manual.** `sponsor_signature`, `sponsor_approval_text`,
  `charter_authorization`, `funding_sources` (Project_Charter_Full) and `funding_source`
  (01_Project_Charter) render as [PM TO COMPLETE] / signature lines — never auto-filled.

## Verification (offline harness against the REAL inlined tool logic)
- Ground-truth counts match exactly:
  - Copilot Pilot (Mini, V-C 39): doc 30 / PMO 17 / TARC 13
  - AB 2123 PFL (Targeted, V-C 87): doc 36 / PMO 17 / TARC 19
- 50,000 randomized count-derivation runs: 0 mismatches.
- 120 real DOCX renders (10 templates × 2 ground-truth exports × 6 reps): 0 errors,
  0 leftover {placeholders}.
- Coverage vs the Template-Map fill model: 5 remaining gaps, all 5 are the true-manual
  fields. TRT Recommendation and CRAID Log are fully covered.
- JS syntax checked; file remains fully self-contained (no CDN references).

## Added: on-load self-check badge (Autogenerate.html)
A small badge (bottom-right) runs once on load, exercising `artifactOwnerCounts`
against three known inputs (the two ground-truth count sets plus an all-headers
edge case). Green "✓ self-check 3/3" means the count-derivation logic behaves in the
browser exactly as in offline verification; red shows the mismatch and logs detail to
the console. It uses no files and no network, never blocks the tool, and is dismissable
by clicking. It is a wiring smoke test, not a substitute for running a real export.

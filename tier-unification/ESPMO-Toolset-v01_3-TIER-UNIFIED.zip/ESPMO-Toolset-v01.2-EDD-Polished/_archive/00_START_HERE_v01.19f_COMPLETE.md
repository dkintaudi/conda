# ESPMO Governance Toolset — v01.19f (Complete Set)

Self-contained, no-CDN browser tools. Open any HTML in 01_Tools_Self_Contained/ directly — no
install, no network. Aligned to CA-PMF (SIMM 19) / SIMM 45 Appendix C complexity.

## The four tools
- **Project-Profiler.html** — questionnaire → Value, Complexity, V–C, band, govTier, artifact list.
  Emits the machine-readable export the Autogenerate consumes.
- **Autogenerate.html** — reads a Profiler export, stamps & assembles the document set.
- **Obligation-Explorer.html** — browse obligations/triggers for a profile.
- **Rules-Admin.html** — view/edit the rule surface (ESPMO_RULES) and bake it back.

## The model (as of v01.19f)

### V–C score
    V–C = Total Value − (Average Complexity × 2.5)
    Average Complexity is the 0–4 mean of Business & Technical → penalty 0–10.

### Bands (three)
    Mini      = both-low: value < 60 AND avgCx < 2.5   → Mini Charter / Mini PMP
    Standard  = Full depth AND V–C < 80
    Targeted  = V–C ≥ 80
The band is keyed to the DEPTH decision at the bottom (Mini = the Mini-template population) and to
the V–C score at the top. Mini is a CORNER (low value AND low complexity), not a V–C slice — the
map draws it as a rectangle, the upper bands as V–C diagonals.

### Governance tier (separate overlay)
    Tier 1 : V–C < 60        baseline docs (+ Mini Charter/PMP when both-low)
    Tier 2 : V–C 60–79       adds Engagement Matrix, RACI, PMP (Full depth)
    Tier 3 : V–C ≥ 80        PMP may split into subsidiary plans; + PIR, Oversight
    Tier 4 : PAL applies     PAL Stage 1–4 gate package (orthogonal process flag)
    Floors: EDD Next → ≥ Tier 3; complexity/PII floors pull tier UP, never depth DOWN.

### Depth selector (Charter + PMP only; RACI NOT depth-gated)
    Mini  ⟺  value_score < 60 AND complexity_avg < 2.5   (raw signals, never the band)
    Full  =  anything else  (high value OR high complexity OR both)
A high-complexity project (avgCx ≥ 2.5) gets Full even inside Tier 1.

## Calibration basis
- 1,000,000-project Monte Carlo on the real scoring maps: natural break ~V–C 60.
- 48-project real-portfolio proxy: confirms portfolio runs lower; Tier 3 caught by FLOORS not score.
- Two real Profiler ground-truth exports: Copilot Pilot → Mini; AB 2123 PFL → Full. Both correct.

## Change history (newest first)
- v01.19f  Optimal band removed → three bands; V–C map redrawn (diagonals + Mini corner rectangle).
- v01.19e  Band "Measured" renamed to "Mini" everywhere (matches CA-PMF template name).
- v01.19d  Mini band DEFINED as the Mini population (band decoupled from pure V–C at the bottom).
- v01.19c  Cutline set to 60/80; band tracks govTier; (Optimal then still a special case).
- v01.19b  Depth selector fixed to value+complexity AND-gate (was the contaminated band).
- v01.19a  Gremlin fixes (fractured header comment; restored partial-column gap reporter).
See the individual 00_*_v01.19*.md notes for the full rationale and verification of each step.

## Verify integrity
    sha256sum -c PACKAGE-MANIFEST.sha256

# Changelog — v01.2 EDD Visual Polish

## Summary
Visual-only consistency pass across the ESPMO toolset.

## Updated
- Project Profiler: EDD-styled masthead, cards, question blocks, live readout panel, buttons, charts, and form controls.
- Autogenerate: EDD-styled header, upload steps, drop zones, status chips, run buttons, logs, and result cards.
- Rules Admin: EDD-styled control surface, status cards, rail navigation, editor cards, inputs, and data grids.
- Obligation Explorer: EDD-styled masthead, panels, cards, controls, tables, and summary blocks.

## Guardrails
- JavaScript application logic was left unchanged.
- Functional behavior, self-contained operation, and browser-only/no-upload posture are unchanged.

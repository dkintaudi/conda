# Archived historical notes

These files are **historical changelogs and superseded start-here / README notes**
from the v01.04 → v01.20 development arc, retained for traceability only. They are
**not** the current entry point and are not needed to use the toolset.

The current entry point for this release is:

    ../00_START_HERE_v01.2_EDD_POLISHED.md

Other current top-level docs:
- `../00_START_HERE_User_Auditor_Guide.docx` — auditor / user guide
- `../00_RULES_TEAM_WALKTHROUGH.md` — rules team walkthrough

Nothing in this folder affects tool behavior; the four tools in
`../01_Tools_Self_Contained/` are self-contained and run without these notes.

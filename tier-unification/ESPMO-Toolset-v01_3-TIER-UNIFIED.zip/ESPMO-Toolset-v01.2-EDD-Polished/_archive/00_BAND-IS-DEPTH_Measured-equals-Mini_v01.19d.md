# Band redefined: Measured = Mini (not a V-C cut) — v01.19d

## The change
Measured is no longer "V-C < 60." Measured is now DEFINED as the Mini population:

    Measured  <=>  Mini  <=>  (value_score < 60 AND complexity_avg < 2.5)
    Standard  =   Full depth AND V-C < 80   (everything below 80 that isn't a Mini)
    Targeted  =   V-C >= 80
    Optimal   =   V-C >= 90   (special-case flag within Targeted; EDD's most-valued, review carefully)

The band is now keyed to the DEPTH decision at the bottom and to the V-C score at the top.
A pure V-C cut could let a high-complexity / low-value project sink its V-C score into the
bottom band and be mislabeled "Measured" while actually needing Full docs. Defining Measured
AS the Mini population removes that contamination permanently: if a project earned Full depth,
it is Standard (or higher) — it can never read Measured.

## Consequence (intended): band and govTier decouple at the bottom
- Band answers "how much documentation": Measured=Mini / Standard=Full&<80 / Targeted / Optimal.
- govTier answers "what oversight regime": V-C cuts (60/80) + floors (eddnextFloor, cxFloorT2) + PAL.
- They may DIFFER at the bottom: a Full-depth project with V-C < 60 is govTier-1 by score but
  band-Standard (it earned Full docs). That is correct and intended — different questions.

## Depth model (unchanged; single source of truth = the AND-gate)
- Measured/Mini : value<60 AND avgCx<2.5  -> Mini Charter + Mini PMP + baseline
- Standard      : Full, V-C<80            -> Full Charter + Full PMP (+ Tier-2 structure if govTier>=2)
  - includes Tier-1-by-score-but-high-complexity (avgCx>=2.5) -> Full, band Standard
- Targeted      : V-C>=80                 -> Full; PMP may split (govTier-3 fan-out)
- Optimal       : V-C>=90                 -> Full; flagged "most-valued, review carefully", no auto escalation
- PAL           : orthogonal              -> Tier 4 gate package
- RACI is NOT depth-gated.

## Verification
- Measured <-> Mini exact equivalence across 867 cells: 0 violations.
- Headline cases: Copilot pilot (v45/cx2.38)->Measured/Mini; low-val/high-cx (v20/cx3.5)->Standard/Full;
  v65/cx2.4 (V-C 59, Full)->Standard; v85/cx3 (V-C 77)->Standard; v95/cx1->Optimal; v30/cx1->Measured.
- vc_band export carries the Mini-first label (r.band); Autogenerate depth gate unchanged (Reading B).
- Profiler + Autogenerate scripts parse clean; all docx templates fill clean.

## Carried from v01.19c
- Cutline 60/80 on govTier (T1<60, T2 60-79, T3>=80); Optimal>=90 special case.
- Calibration: 1M Monte Carlo (natural break ~60), 48-project proxy (runs lower, timid at top),
  two real ground-truth exports (Copilot Pilot->Mini, AB 2123->Full).

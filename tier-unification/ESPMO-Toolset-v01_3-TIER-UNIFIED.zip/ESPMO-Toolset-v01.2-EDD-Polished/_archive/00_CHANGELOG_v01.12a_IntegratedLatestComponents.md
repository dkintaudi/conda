# Changelog – v01.12a Integrated Latest Components

Built from the latest uploaded v01.12a Autogen/gap-reporter reference and the full Profiler-enabled toolset shell.

## Included component versions

- Profiler: v01.06 TRT Recommendation Deck strengthened export.
- Autogenerate: v01.19 Draft-Friendly Evidence Gate.
- Templates: latest v01.19 Autogenerate templates, template map, and template paths.
- Preserved: Rules Admin, Obligation Explorer, QA checks, reference workbooks, and existing user/auditor documentation from the full toolset.

## Notes

The uploaded v01.12a zip was confirmed to be an Autogen-side package, not a full toolset by itself. This integrated package restores the full toolset structure and places the latest components in their correct locations.

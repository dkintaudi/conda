# ESPMO Governance Toolset v01.03 — User Portable Pack

This pack contains the self-contained browser tools for normal use. Open the HTML files from the extracted folder. No CDN, server, npm install, or network connection is required.

## Tools Included

- Project Profiler — completes the project intake / governance scoring profile and exports machine-readable handoff data.
- Obligation Explorer — reviews governance obligations and rationale.
- Auto Generator — uses the supplied loose working Autogenerate build (v01.06), reads pasted TRT/profiler source text or profiler exports, generates drafted templates, and can produce the project schedule.
- Rules Admin — supports rule/workbook administration.

## Opening and Using the Tools

Opening any of the self-contained HTML tools should not create a pile of files by itself. Routine use runs locally in the browser. Normal Windows/browser traces may still exist, such as browser history, recent-file entries, temporary cache files, or zip-preview extraction folders if the tool is opened from inside a compressed zip.

File clutter usually comes from repeatedly downloading the package, opening files directly from inside a zip, extracting multiple copies, or exporting/generated outputs. Best practice is to download once, extract once to a controlled project folder, open the HTML tools from that extracted folder, and save generated outputs to a known project location.

## Schedule Generation Note

When the Auto Generator receives Profiler output with deliverable IDs, the generated schedule is stamped with the Profiler-selected deliverable set. The schedule workbook format, formulas, and styling are preserved. The `Profiler Required?` helper/filter column is populated Yes/No and the schedule opens filtered to the Profiler-required items, while preserving schedule context rows such as milestones, phase gates, or summary rows when present. Methodology is not stamped into the F9 project-info cell; methodology remains available in the schedule grid as a normal filterable column.

## Recommended Launch Folder

Keep this folder intact after extraction:

```text
User-Pack/
```

Open tools from:

```text
01_Tools_Self_Contained/
```

## Optional template QA check

A Python validation script is included in `04_QA_Checks/`. It can be run before sharing the package to confirm the Word templates and examples do not contain blank table rows, spaced placeholders, or shortened risk responses.



## v01.03 Packaging Note

This v01.03 package replaces every bundled `Autogenerate.html` copy with the supplied loose working Autogenerate file. The Auto Generator application badge remains v01.06 because that is the working tool build placed into this package.

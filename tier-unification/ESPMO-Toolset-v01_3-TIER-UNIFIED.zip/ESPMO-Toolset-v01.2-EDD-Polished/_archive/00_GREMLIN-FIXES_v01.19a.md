# Senior-dev review of the v01.19 build — gremlins found & fixed (v01.19a)

Two issues were found in the user-provided v01.19 Autogenerate build (assembled with ChatGPT)
and corrected:

1. FRACTURED HEADER COMMENT (parse-breaking).
   The top-of-file HTML banner comment had been split by a stray C-style `/* ... */` pair, with
   a sentence fragment ("block near the end of this file …") left stranded as live code. This is a
   hard parse error. Fixed: restored a single clean HTML comment (`<!-- … -->`) after `<!DOCTYPE html>`,
   removed the stray `/*` and `*/`, and mended the truncated sentence. Verified: DOCTYPE present,
   single banner close, all scripts load.

2. DROPPED PARTIAL-COLUMN GAP FIX (regression vs. earlier work).
   The v01.19 build did not carry the gap-reporter partial-column wording fix. A loop gap where the
   SECTION HAS ROWS but one column came through empty fell back to a generic/loop-level message.
   Re-applied: such gaps now read "Column not provided for these rows — the section has rows, but
   this field came through empty"; whole-empty sections still read "No rows for this section …".

Verified after fixes: all 5 docx templates fill clean (zero leftover placeholders); band selection
correct (Measured = 5 docs incl. Mini charter + Mini PMP, no standalone Governance Plan; Standard+
= 6 docs); governance gating intact; gap reporter classifies scalar/manual/row-field/section gaps
correctly. Build tagged v01.19a.

NOTE: v01.19 is a higher tool version than the v01.12a line; it adds a "draft-friendly evidence
gate." That feature was left intact — only the two defects above were touched.

# Band renamed: "Measured" -> "Mini" everywhere (v01.19e)

## Why
"Measured" was an internal label, not a CA-PMF term (CA-PMF's complexity scale is low/medium/high;
"Mini" is CA-PMF's name for the template variant — Project Charter (Mini), PMP (Mini), RACI (Mini)).
Since v01.19d defined this band AS the Mini population (both-low: value<60 AND avgCx<2.5), the band
and the template it triggers are the same set. Naming the band "Mini" makes that self-documenting:
the Mini band carries the Mini templates.

## Bands now
    Mini      <=>  both-low (value<60 AND avgCx<2.5)  -> Mini Charter / Mini PMP
    Standard  =   Full depth AND V-C < 80
    Targeted  =   V-C >= 80
    Optimal   =   V-C >= 90  (special-case flag; EDD's most-valued, review carefully)

## What changed
- Profiler: all live band-label sites (quadName, band, BANDINFO map key+labels, xlsx band formula,
  fullName map, SVG quadrant text) now emit "Mini". vc_band export carries "Mini". Comments refreshed.
- Autogenerate: comments updated (depth gate keys off raw value_score/complexity_avg, never the label,
  so no logic change — the rename is cosmetic here).
- Obligation-Explorer: ALSO had stale pre-v01.19d band logic (vc>=70 pure-V-C cut). Brought in line —
  now uses the Mini-first definition matching the Profiler, not just relabeled.
- Rules-Admin: UI helper text updated ("below, if both-low, is 'Mini'").

## Verification
- Zero "Measured" remaining in any tool file.
- All four tools' scripts parse clean.
- Band partition intact: Copilot pilot->Mini, v30/cx1->Mini, v20/cx3.5->Standard, AB2123->Targeted,
  v85/cx3->Standard.
- BANDINFO[quadName] lookup resolves to the renamed 'Mini' key (no literal 'Measured' lookups).
- q-mea CSS class preserved (only the comment changed).
- All docx templates fill clean.

## Carried from v01.19d / c
- Measured(now Mini) = Mini population by definition; band decoupled from pure V-C at the bottom.
- Cutline 60/80 on govTier; Optimal>=90 special case.
- Depth gate Reading B (value<60 AND avgCx<2.5); RACI not depth-gated.

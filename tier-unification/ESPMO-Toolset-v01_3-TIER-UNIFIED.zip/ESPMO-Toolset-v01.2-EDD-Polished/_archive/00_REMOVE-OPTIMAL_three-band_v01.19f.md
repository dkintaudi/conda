# Optimal band removed — three-band model (v01.19f)

## What & why
Optimal (V-C >= 90) is removed. Audit of all four tools confirmed it was PURE DISPLAY: every
reference was a label, a tunable threshold, or the Rules-Admin control for that threshold. Nothing
branched on it — no document trigger, tier calc, or gate keyed off Optimal. A V-C 95 project was
treated identically to a V-C 81 project for every actual outcome (both Targeted / Tier 3). So the
band carried a distinction that drove no decision. Removed.

## Bands now (three)
    Mini      <=>  both-low (value<60 AND avgCx<2.5)   -> Mini Charter / Mini PMP
    Standard  =   Full depth AND V-C < 80
    Targeted  =   V-C >= 80

These track govTier 1:1: Mini=T1, Standard=T2, Targeted=T3 (PAL still forces T4, orthogonal).

## Nothing lost
- vc_score (raw V-C) is still emitted in the export. The "top of Targeted" / >=90 view is recoverable
  anytime by filtering vc_score>=90 — the data is intact, only the pre-computed label is gone.
- Tier 3 still caught for the big programs via govTier floors (eddnextFloor, PAL), unchanged.

## Changed
- Profiler: band expressions (2 JS + xlsx formula), BANDINFO/fullName/BLUE/bandKey maps, SVG quadrant
  Optimal region+label, caption top-tier line, vcBands rules (Optimal:90 dropped).
- Obligation-Explorer: band expression + baked vcBands.
- Rules-Admin: removed the "Optimal band" control, its export row, read-back, and the validation
  (now checks targeted>standard only, no longer requires optimal>targeted).
- q-opt CSS class retained — it is reused by the unrelated SIMM complexity-zone map, not the band.

## Verification
- Zero band-Optimal references remain (q-opt zone-map class intentionally kept).
- V-C 95 -> Targeted (was Optimal); Mini/Standard/Targeted are the complete set.
- All four tools parse clean; BANDINFO has exactly 3 keys; all docx templates fill clean.

## Carried from v01.19e/d/c
- Mini band = Mini population (Measured renamed to Mini); cutline 60/80; depth gate Reading B
  (value<60 AND avgCx<2.5), RACI not depth-gated; two real ground-truth confirmations.

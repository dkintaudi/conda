# ESPMO Governance Toolset — v01.04 (Narrative Rules)

Built on the v01.03 Natural-TRT package. This release wires the narrative-generation
layer end-to-end so charters fill from Profiler answers, not just deck transfer.

## What changed vs v01.03

**Autogenerate** (now carries the narrative engine)
- Added ESPMO_NARRATIVE_RULES block (AnswerText + Rule-1 business_problem +
  Rule-3 objective-measure harvest), consumed by applyNarrativeRules() in buildData().
- Every answered intake question emits a {id}_text sentence (method_text, phase_text,
  loe_text, spend_text, etc.). nullGetter-safe: no answer -> no _text.
- Rule-1 composes business_problem ONLY when a dropped TRT supplies none (deck wins).
- Rule-3 harvests a measurable target from benefits/proposed_solution/recommendation;
  three honest tiers, never fabricates a number.
- PATCH: composed business_problem now always ends in terminal punctuation
  (fixes a dangling fragment when only phase was answered). Idempotent; deck-fed
  prose untouched.

**Project-Profiler** (feeds the engine)
- Emits intake answers as Fields rows, one per answered question, tagged by stable
  semantic id (loe, spend, method, ...) plus a positional Q## alias. This is the
  bridge that lets Autogenerate compose prose from Profiler facts.
- LOE question present: Small <500 hrs / Medium 500-10,000 / Large >10,000 /
  Not-yet-sized -> codes s/m/l/u (matches AnswerText loe rows exactly).

**Rules-Admin** -> v01.04
- Second bake target: buildNarrativeRules() + publishNarrativeInto() rebuild the
  ESPMO_NARRATIVE_RULES block in Autogenerate from the workbook
  (AnswerText / BusinessProblemRule / ObjectiveMeasureRule sheets).

**Reference**
- Added narrative_rules_v01.json and ESPMO_Rules_AnswerText_ADDITION.xlsx
  (the bake source of truth for the narrative surface).

## LOE round-trip (verified)
Profiler emits loe={s|m|l|u} -> Autogenerate nr_emitAnswerText fills loe_text.
Deck fallback: PARSE_RULES regexes map "small / <500 hrs" etc. to the same loe code.
Rule-1 estimate clause joins spend + loe ("...under $250,000 and a small level of
effort (under 500 hours).") when composing a business_problem.

## Note
Profiler header still self-labels "v01.02" — cosmetic; functionally it is the
latest (v01.03 base + field-emission upgrade).

## v01.04a — Charter field gap-fill (buildData) + template alignment

Closes the 9 charter fields that were neither Profiler- nor narrative-emitted.

**Autogenerate buildData() — gap-fill after applyNarrativeRules:**
- version_number -> "Draft v1.0" (a generated charter is always first draft)
- date_prepared  -> today, spelled out ("June 19, 2026"); mm/dd/yyyy fallback
- est_total_cost -> mirrors Profiler spend band (data.spend) when unset
- capmf_phase    -> aliases data.phase (safety; template now uses {phase} directly)
- project_manager-> aliases data.pm (TRT extractor emits pm)

**Autogenerate TRT role extractor:**
- Added project_sponsor matcher (Business Sponsor / ITB Project Sponsor /
  Project Sponsor) alongside existing it_sponsor and pm. Roles now resolve from
  the TRT recommendation / provided text, as intended.

**Charter template (01_Project_Charter_TEMPLATE.docx):**
- {capmf_phase} -> {phase} so it reads the intake answer directly.

**Remaining manual fields (no Profiler/TRT source, by design):**
- funding_source, fiscal_years — PM-entered at charter time.

## v01.04b — Colon-layout role extraction

The TRT "Resource Allocation:" slide uses a label:value layout
("Business Sponsor: <name>  ITB Project Sponsor: <name>  Project Manager (PM): <name>").
The prior sentence-style matchers mangled or missed this layout even when names
were present.

- Added _roleColon() matchers (label-guarded names; a following label is never
  mistaken for a name). Maps Business Sponsor -> it_sponsor, ITB/Project Sponsor
  -> project_sponsor, Project Manager (PM) -> pm.
- Behavior: names extracted when the TRT lists them; BLANK role lines yield blank
  (no fabrication). Roles come from the TRT/provided text — they populate only when
  the TRT author has filled them in.

## v01.04c — Visible gap markers + charter-only guard

- Every charter slot with no source now renders "[PM TO COMPLETE]" instead of a
  silent blank: measure, roles, funding_source, fiscal_years, and any empty loop
  section (milestones/risks/objectives/etc.). A generated charter self-documents
  exactly what still needs a human.
- All charter enrichment (gap-fill + markers) is now gated to charter templates
  only (/charter/i on templateKey). Non-charter templates — Stakeholder Register,
  CRAID Log, Engagement Matrix, TRT Recommendation — are untouched. (This also
  fixes a latent issue where the earlier gap-fill ran for every template.)

### Honest fill summary (30 charter fields)
- 9 always fill from a completed Profiler (+ 2 constants: Draft v1.0, today).
- 19 fill IF the deck / TRT recommendation / pasted text carries the content
  (business_problem, measure, 3 roles, 14 loop fields). Richer source = fuller charter.
- 2 never auto-fill (funding_source, fiscal_years) — PM-entered.
- Unfilled conditionals + the 2 manuals now show [PM TO COMPLETE].

## v01.04d — Template-driven field discovery (Thing 1)

The fill/mark pass no longer uses a hardcoded field list. At generation time it
reads the ACTUAL {placeholders} out of each template's XML (document + headers +
footers) via extractTemplateFields(), then:
  - fills scalar placeholders from Profiler/TRT data (after the gap-fills run);
  - marks any unfilled scalar [PM TO COMPLETE];
  - marks empty loop sections with a single [PM TO COMPLETE] row.
Loop vs scalar is detected by the {#tag}/{/tag}/{^tag} sigils. Row-internal loop
fields (item/num/milestone/risk/statement/response/target_date) are skipped at the
top level. Edit a template (add/rename a field) or drop in a new one and the tool
adapts with no code change.

Also lays the data layer for the on-screen gap report (Thing 2): buildGapReport()
records each unfilled placeholder + WHY (PM-entered / not named in TRT / no metric /
no source) onto data.__gapReport. UI surfacing comes next; the docx still shows the
inline [PM TO COMPLETE] markers.

templateBuf is now threaded into buildData(recipe, templateKey, templateBuf).

## v01.04e — On-screen "what it didn't fill" dropdown (Thing 2)

The results panel now shows a collapsible <details> dropdown after generation:
"N fields left for you to complete (marked [PM TO COMPLETE] in the draft)".
Expanding it lists, per document, each placeholder that did NOT fill and WHY
(PM-entered / not named in TRT / no metric / no source / empty section) — read
straight from data.__gapReport recorded during generation. The .docx itself is
unchanged (still carries the inline [PM TO COMPLETE] markers).

The old pre-generation lint that warned "...may not populate automatically" was
reworded to a template-hygiene check (flags unrecognized placeholder names /
possible typos) and now points the user to the post-generation list for the
actual gaps — so the tool reports what it DIDN'T do, not what it MIGHT not do.

## v01.04f — Gap reasons from Template-Map + PowerPoint template support

**Gap reasons now come from your governance data (ESPMO-Template-Map.xlsx).**
- Drop the Template-Map alongside the Profiler/templates and the tool loads its
  Placeholders sheet (loadPlaceholderMap). The on-screen gap report explains each
  unfilled field using fill_type + profiler_field from the map: "(manual)" -> PM-
  entered, "(intake)" -> from intake not answered, auto -> expected Profiler field X,
  copilot -> drafted in Word, loop -> no rows. Falls back to the built-in reasons
  only when a field isn't in the map. Add a row to the workbook and a new field's
  reason is correct with no code change.
- Fixed a latent collision: the path-map resolver (MAP_NAME) used to also match
  "template-map", risking it parsing the placeholder dictionary as a path map.
  MAP_NAME now matches paths/locations only.

**Templates can now be Word OR PowerPoint.**
- The fill engine (discovery + fill + mark + gap report) now reads OOXML body parts
  for .docx AND .pptx (ppt/slides/*). docxtemplater fills both natively; verified
  headless that {placeholders} and {#loops} populate in a .pptx.
- Excel (.xlsx): docxtemplater's placeholder fill needs the paid XlsxModule, which
  this build does not include. .xlsx templates are routed to the existing SheetJS
  cell-stamping path (same as the embedded Project Schedule) and given a clear
  message rather than a cryptic engine error. Output filenames preserve the source
  extension (.docx/.pptx).

## v01.04g — Template-Map drives FILLS, not just reasons

ESPMO-Template-Map.xlsx is now a translation table for filling, not only for
explaining gaps. After Profiler name-matching and the built-in aliases run, an
applyMapFill pass walks the map: for any placeholder still empty whose map row
names a concrete profiler_field, it copies that field's value in. So a template
can use {est_total_cost} and the map can route it to the "spend" field with no
code change — set the profiler_field cell in the workbook and it flows.
  - Name-match stays primary; the map is the documented fallback.
  - "(manual)" / "(intake)" / blank profiler_field are NOT treated as sources
    (those remain PM-entered and get marked / listed).
  - This lets the hardcoded aliases (capmf_phase->phase, est_total_cost->spend,
    project_manager->pm) be migrated into the workbook over time, moving the
    mapping into governance-controlled data instead of code.

Note on naming: "recipe" is kept (not renamed to ProfilerFields) because it holds
three things — { templates, fields, loops } — not just the Profiler fields. The
field slice is already recipe.fields.

## v01.04h — Internal rename: recipe -> profileBuild

The in-memory object holding { templates, fields, loops } is renamed from "recipe"
to "profileBuild" throughout the code, including dependent identifiers
(parseProfileBuild, combineProfileBuilds, profileBuildField, profileBuildName,
knownNamesFromProfileBuild, renderProfileBuildStatus, capProfileBuildSourceContext,
profileBuildProjectName). 97 bare references + the helpers, all verified def/call
aligned, script parses clean, token diff shows only recipe-family -> profileBuild-
family changed (no accidental hits).

FROZEN (intentionally NOT renamed): the UI element ids recipeInput, recipeLog,
recipeFiles, dropRecipe. These are HTML<->JS paired strings; renaming them is user-
invisible and is exactly where a silent drop-zone break would hide, so they stay.
Purely internal; no behavior change.

## v01.04i — UI ids renamed too (recipe* -> profileBuild*)

The four element ids previously frozen are now also renamed, in lockstep across
their HTML id="" attribute and every JS lookup:
  recipeInput -> profileBuildInput   (1 HTML + 1 JS)
  recipeLog   -> profileBuildLog     (1 HTML + 11 JS)
  recipeFiles -> profileBuildFiles   (1 HTML + 2 JS)
  dropRecipe  -> dropProfileBuild    (1 HTML + 1 JS)
Verified: the string "recipe" now appears ZERO times anywhere in Autogenerate;
each renamed id has a matched HTML attribute + JS reference (no orphaned id/lookup);
script parses clean. No CSS selectors referenced these ids (styled by class), so
there was no hidden third reference site. Behavior unchanged — purely cosmetic.

Caveat: id<->lookup pairing is proven statically; the drop zone still warrants a
single live click to confirm in a real browser, since DOM resolution can't be
exercised headlessly.

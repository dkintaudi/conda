# Mini/Full depth selector — corrected to a value+complexity AND-gate (v01.19b)

## What changed
`charterBandDecision()` (drives Mini vs Full for the Charter and PMP pairs) was re-pointed
from the blended V-C band to an AND-gate on the two RAW Profiler signals:

    Mini  <=>  value_score < 50  AND  complexity_avg < 2.5
    Full   =   anything else (high value OR high complexity OR both)

Reads `value_score` (0–100) and `complexity_avg` (0–4) directly from the Profiler export.
Thresholds are the Profiler's own cutlines (valueHigh 50, zoneThreshold 2.5).

## Why (the bug it fixes)
V-C = value − (avgComplexity × 2.5). Because complexity SUBTRACTS, a high-complexity
project is pushed DOWN into the Measured band — so the old band-keyed selector handed a
MINI to complex projects. Enumeration over a (value 0–100 × avgCx 0–4) grid found 88
disagreement cells, ALL the same direction: band said Mini, AND-gate said Full. Examples:
  - value 70, avgCx 4 (max complexity) -> V-C 60 -> Measured -> OLD: Mini  NEW: Full
  - value 10, avgCx 4                  -> V-C  0 -> Measured -> OLD: Mini  NEW: Full
  - value 20, avgCx 3.5                -> V-C 11 -> Measured -> OLD: Mini  NEW: Full
True both-low pilots (e.g. value 30, avgCx 1) still resolve to Mini — the gate does not
over-correct.

## Scope
- Applies to the Charter and PMP mini/full pairs ONLY.
- RACI is intentionally NOT depth-gated (and is not a built template in this package).
- Subsidiary-plan fan-out and govTier/PAL/EDD-Next obligations are unaffected — those
  remain separate axes (complexity drives fan-out; govTier drives obligations, additive).

## Verification
- Patched function tested against the full (value × avgCx) grid: 0 mismatches vs the AND-gate.
- Headline cases: value90/cx1.2->Full, value70/cx4->Full, value10/cx4->Full,
  pilot v30/cx1->Mini, v45/cx2->Mini, v80/cx1->Full, v20/cx3.5->Full.
- All 5 docx templates fill clean; governance band gating (Measured=5 / Standard+=6) intact;
  scripts parse clean.

## Fallbacks
When value_score/complexity_avg are absent (older exports), falls back to vc_read/vc_band,
then vc_score>=70 — never silently dropping a file. New exports always carry the raw signals.

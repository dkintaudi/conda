# V-C cutline set to 60/80, band collapsed to track govTier, Mini gate widened (v01.19c)

## Changes
1. **Cutline 60/80.** V-C band and govTier now share cutlines and track 1:1:
   - Measured / Tier 1 : V-C < 60
   - Standard / Tier 2 : 60–79
   - Targeted / Tier 3 : >= 80
   Set in ESPMO_RULES: vcBands.Standard 70->60; govTier.t1Max 70->60; tierCut.t2 50->60, t3->80.
   Band-label expressions (2 JS + 1 xlsx formula + narrative + map key) all moved to the 60 cut.

2. **Optimal (V-C >= 90) = special-case flag, not a 4th tier.** Still labeled "Optimal" and
   surfaced for prioritization, but governance-wise it is a Tier 3 project. Reserved for EDD's
   most-valued efforts regardless of complexity — a "review carefully" marker, NOT an automatic
   document or tier escalation (auto-escalation would re-introduce value-contaminates-depth).

3. **Mini/Full depth gate widened to value < 60 (Reading B).** Mini <=> value_score < 60 AND
   complexity_avg < 2.5. The value cut was raised 50->60 to align with the new T1/T2 line; both
   tests remain on RAW signals (NOT the V-C band). Rejected "Reading A" (V-C < 60 AND cx < 2.5)
   because a high-value project dragged under V-C 60 by its complexity penalty would wrongly get
   a Mini — the same contamination bug fixed in v01.19b.

## Depth model (single source of truth = the AND-gate)
- Tier 1 both-low (value<60 AND avgCx<2.5)  -> Mini Charter + Mini PMP + baseline
- Tier 1 high-complexity (avgCx>=2.5)        -> FULL (complexity crossing 2.5 forces Full even in Tier 1)
- Tier 2 (60-79)                             -> Full/standard (nothing both-low reaches V-C 60)
- Tier 3 (>=80)                              -> Full; PMP may split into subsidiary plans
- Tier 4                                     -> PAL gate package (orthogonal process flag)
- RACI is NOT depth-gated.

## Calibration basis (paper trail)
- Monte Carlo, 1,000,000 simulated projects on real ESPMO scoring: mean/median V-C 52; natural
  upper-tertile break at V-C 59.8 (~60); 60/80 split = 67/28/5%, stable to 0.1% across 5 batches.
- Real-portfolio proxy (48 baseline projects, estimated inputs): runs lower/tighter (mean 46,
  max 78); proxy is reliable at the low end, timid at the top (under-scores big EDDNext programs
  whose value lives in facts the baseline index didn't capture). Tier 3-by-score is therefore
  rare; the big programs reach Tier 3 via govTier FLOORS (eddnextFloor) by design, not by score.
- Two REAL Profiler ground-truth exports confirm the depth gate:
    Copilot Pilot  : Value 45, avgCx 2.38, V-C 35-39, Measured -> Mini  (correct: it is a pilot)
    AB 2123 PFL    : Value 95, avgCx 3.24, V-C 87,    Targeted -> Full  (correct)
  Copilot's low score is correct, not an intake error: it is scoped as a pilot, and CA-PMF
  reserves the Mini for "pilot projects and proof of concept." The AND-gate = the pilot/POC detector.
- 60 chosen over the proxy's ~55 lean deliberately: matches the simulation's natural break and is
  defensible/memorable; proxy lowness is partly an artifact of under-scored top-end programs.

## Verification
- Patched gate == Reading B across 867 cells: 0 mismatches.
- No project with value >= 60 ever receives Mini (contamination bug stays closed).
- Band level == score-tier across the grid at 60/80: 0 mismatches (they track 1:1).
- Real points: Copilot -> Mini, AB 2123 -> Full. Tier-1 high-cx (v20/cx3.5) -> Full.
- All docx templates fill clean; both tools' scripts parse clean.

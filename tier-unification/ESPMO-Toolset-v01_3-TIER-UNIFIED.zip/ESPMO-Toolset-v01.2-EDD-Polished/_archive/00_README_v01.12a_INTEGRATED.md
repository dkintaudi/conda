# ESPMO Toolset v01.12a – Integrated Latest Components

This is the clean full toolset package.

## Current key components

- `01_Tools_Self_Contained/Project-Profiler.html` – Profiler with strengthened TRT Recommendation Deck export.
- `01_Tools_Self_Contained/Autogenerate.html` – Autogenerator with v01.19 draft-friendly TRT/business-case evidence gate.
- `02_Templates_and_Reference.zip` – latest Autogen templates, map, and paths included under `02_Templates_and_Reference/02_Templates/`.

## Component boundary

The uploaded v01.12a gap-reporter package was an Autogen/template component package. This zip is the full integrated toolset package.

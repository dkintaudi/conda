# ESPMO Toolset v01.12a — FULL Verified Latest Components

Open tools from `01_Tools_Self_Contained/`:

- `Project-Profiler.html` — latest Profiler with strengthened TRT Recommendation Deck output.
- `Autogenerate.html` — latest Autogenerator with draft-friendly evidence gate and updated template wiring.
- `Rules-Admin.html` and `Obligation-Explorer.html` — preserved support tools.

Templates and maps are stored in `02_Templates_and_Reference.zip`.

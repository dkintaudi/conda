# v01.12a FULL Verified Latest Components

This package was assembled using the latest user-provided v01.12a Autogenerator/gap-reporter upload as the current Autogen-side reference, while preserving the full toolset structure.

Included component updates:

- `01_Tools_Self_Contained/Project-Profiler.html` replaced with the v01.06 Profiler that strengthens the TRT Recommendation Deck export.
- `01_Tools_Self_Contained/Autogenerate.html` replaced with the v01.19 Autogenerator draft-friendly evidence gate build.
- `02_Templates_and_Reference.zip` rebuilt to include the v01.19 templates, template map, and template paths.
- Existing Rules Admin, Obligation Explorer, QA checks, reference workbooks, guide files, and filled examples were preserved from the full toolset shell.

Generated: 2026-06-20 07:45:36 UTC

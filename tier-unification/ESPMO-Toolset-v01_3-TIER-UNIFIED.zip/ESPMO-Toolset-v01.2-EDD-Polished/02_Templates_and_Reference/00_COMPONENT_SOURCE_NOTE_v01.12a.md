# Component Source Note – v01.12a Integration

This integrated package was built using the user's uploaded v01.12a gap-reporter package as the latest Autogen-side reference file.
The full toolset shell is preserved from the Profiler-enabled toolset package, then updated with:
- Project Profiler v01.06 TRT Recommendation Deck export
- Autogenerate v01.19 Draft-Friendly Evidence Gate
- Latest Autogenerate templates/maps/paths from v01.19

The uploaded v01.12a package was inspected and confirmed to contain Autogenerate/templates only; it did not include the Profiler, Rules Admin, Obligation Explorer, QA checks, or reference workbook folders.

# ESPMO Templates — Profiler + TRT + AnswerText wiring

## 1. Charter selection by V-C band (NEW in v01.09)
The Profiler reads the V-C score into a band (vc_read): Measured < Standard < Targeted < Optimal
(score thresholds <70 / 70-79 / 80-89 / >=90). Charter depth now follows the band automatically:
  - Measured            -> Project Charter (Mini)
  - Standard and above  -> Project Charter (Full)
Logic lives in neededTemplates() + neededTemplatesForPhase() via applyCharterBandFilter().
It only ever chooses BETWEEN the two charter files when both are marked generate=Y. If the band
label is absent it falls back to vc_score (>=70 => Full); if neither is present it keeps both
(never a silent drop).

The other five deliverables are BASELINE — they generate in every band whenever generate=Y:
Project Management Plan, Governance Management Plan, Stakeholder Register, CRAID Log, RTM.

## 2. AnswerText wired in (NEW in v01.09)
AnswerText (nr_emitAnswerText) emits 22 prewritten sentences under *_text tags from the Profiler
intake answers (method, phase, spend, data, pal, eddnext, coord, vendor, loe, impact, support,
testing, pmexp, sec, mandate, migrate, cloud, deps, newcap, benefit, novelBiz, novelTech). It runs
inside applyNarrativeRules BEFORE applyMapFill, so the _text tags are available as map sources.

11 former-Copilot slots now prefer an AnswerText sentence, with Copilot only as last resort when
the Profiler didn't carry that answer:
  sp_communications  <- coord_text       sp_resource        <- vendor_text
  sp_schedule        <- loe_text         sp_quality         <- testing_text
  sp_stakeholder     <- impact_text      sp_mo_transition   <- support_text
  sp_change_control  <- method_text      assumptions_summary<- data_text
  constraints_summary<- pal_text         staffing_essentials<- pmexp_text
  gov_structure      <- eddnext_text

## 3. Source priority (unchanged from prior step)
Every scalar prefers: Profiler build field / TRT Recommendation field -> AnswerText sentence ->
PM-entered (dates, funding, approval text) -> Copilot last resort.

## Files
- Autogenerate_v01.09_BAND-ANSWERTEXT.html  (use in place of v01.07/08)
- ESPMO-Template-Map_UPDATED.xlsx            (sources + AnswerText routing)
- template-paths_UPDATED.xlsx                (all 7 filenames registered)
- 4 .docx templates + 3 .xlsx templates

Filenames are the match key — keep them stable or re-key the Templates sheet. The charter band
filter recognizes the two charters by filename (contains "charter"; "mini" => Mini), so a rename
to a canonical scheme keeps working as long as that still reads true.

## 4. Mini PMP added + band-gated (NEW in v01.10)
CA-PMF defines a Mini Project Management Plan (Project_Management_Plan_PMP_Mini_Template_Shell)
for smaller / lower-V-C efforts. Built Project_Management_Plan_Mini_TEMPLATE.docx in EDMS house
format following the official CA-PMF Mini PMP structure:
  1 Project Summary · 2 Roles & Responsibilities · 3 Subordinate Plans
  (3.1 Communications · 3.2 Schedule · 3.3 Issue · 3.4 Risk · 3.5 M&O Transition)
— five subordinate plans vs. the full PMP's sixteen.

Band selection now covers BOTH pairs identically (same V-C / volume score as the charter):
  Measured            -> Charter (Mini) + PMP (Mini)
  Standard and above  -> Charter (Full) + PMP (Full)
The Governance Management Plan is explicitly excluded from the PMP pair (isManagementPlanFile
rejects /governance/) and remains a baseline doc. Implemented via applyDepthBandFilter() called
once per pair inside applyCharterBandFilter().

Mini PMP scalar sources: project_summary <- recommendation (TRT); subordinate_intro <-
proposed_solution (TRT); header band identical to the other docs. Its five subordinate tables are
loops (communications, schedule, issues, mini_risks, mo_transition).

## 5. Governance Plan gated off for Measured (NEW in v01.11)
CA-PMF ships only ONE Governance Management Plan — there is no mini variant. Policy (ESPMO):
a Measured-band project does NOT get a standalone Governance Plan; its governance content is
considered covered by the Mini PMP's Roles & Responsibilities / decision sections, consistent
with CA-PMF ("documenting how decisions are made in the PMP meets the governance objective").

  Measured            -> NO standalone Governance Plan (Mini PMP carries it)
  Standard and above  -> standalone Governance Management Plan generated

Implemented as applyGovernanceBandFilter() inside applyCharterBandFilter(). Gates off only when
the band is KNOWN and resolves to Measured; unknown band keeps the Governance Plan (never a
silent drop).

Resulting per-band doc set (all generate=Y):
  Measured : Charter (Mini) · PMP (Mini) · Stakeholder Register · CRAID · RTM        = 5 docs
  Standard+: Charter (Full) · PMP (Full) · Governance Plan · Stakeholder · CRAID · RTM = 6 docs


## 6. Gap reporter corrected + roles table synthesis (NEW in v01.12)
The gap reporter now distinguishes loop-child placeholders from top-level charter fields. Fields such as `{role}`, `{assigned_to}`, `{responsibility}`, `{start}`, `{end}`, `{owner}`, `{severity}`, `{category}`, and `{estimate}` are treated as row fields inside their parent loops, not standalone missing scalar fields.

Roles are also now synthesized into the charter `{#roles}` loop when the Profiler/TRT provides named role fields such as `project_sponsor`, `pm` / `project_manager`, `it_sponsor`, `it_lead`, `business_owner`, or `system_owner`. Existing role rows are patched with default responsibility language when the responsibility cell is blank.

Gap reporting behavior after this change:
  - populated role rows no longer show `{role}` or `{responsibility}` as missing;
  - empty loops report as a section gap, such as `roles (section)`;
  - partially populated loops report as row-field gaps, such as `milestones.start` or `budget.estimate`.


## v01.15 TRT-derived governance fields

- Risks, assumptions, constraints, and dependencies can now be synthesized from TRT Recommendation fields and sections when structured rows are not provided.
- Generated rows are clearly labeled `Source: TRT Recommendation — ...` so reviewers know they are first-draft TRT-derived content, not confirmed PM-entered values.
- Funding source and sponsor signature remain PM/sponsor-complete fields.


## v01.16 update - TRT evidence gate
- Added a TRT/DCT evidence gate for .docx/.pptx/.xlsx/pasted TRT sources.
- Incomplete TRT recommendations still pass when they include recommendation/disposition/LOE/referral evidence.
- Non-TRT decks are rejected with a plain-language message instead of being lightly parsed from generic words such as benefits, sponsor, timeline, or risk.
- When a Profiler is loaded with a non-TRT deck, the Profiler still loads but the skipped deck is surfaced as a warning.


## v01.18 — Business-case evidence gate
Broadened the text/Paste/Word evidence gate so valid work-intake writeups can pass even when they do not use formal TRT Recommendation wording. The gate now accepts a defensible business-case core when the input includes Business Problem/Background, Benefits, Impact if not completed, and at least one operational/governance anchor such as Impacted Systems, LOE, rollout/deployment approach, Change Record, Work Intake, DCT approval language, or role allocation.

Safety corrections:
- Removed the unsafe loose `supports` match that could treat ordinary language such as “EDD supports MFA” as a recommendation.
- Removed the unsafe standalone `as` disposition match that could treat “as an additional MFA method” as a disposition.
- Added recognition for `LOE is estimated as Large/Medium/Small` and `CHG######` change-record identifiers.
- Kept the nonsense gate: business-case-shaped cartoon/test text is still rejected unless it carries hard governance facts.

## v01.19 — Draft-friendly evidence gate
Lightened the Word/Paste evidence gate for draft generation. The tool now accepts weaker but still usable source text when it has enough project/business-case structure to create a reviewable draft, even if it lacks formal TRT/DCT language.

Accepted draft-friendly inputs can include combinations such as:
- Background + Benefits;
- Business Problem + Impact if not completed;
- Benefits + Impact;
- Background/Approach + Impacted Systems;
- rough email-style work-intake notes with project, rollout, system, or role signals.

Guardrail behavior:
- Plain random/gibberish text still rejects.
- Generic status/training/sales decks still reject when they only contain loose terms like benefits, timeline, or project manager and no recommendation/business-case core.
- File uploads remain slightly stricter than pasted text; a file with only Background + Benefits and no impact, systems, LOE, work-intake/change reference, business problem, or role allocation is treated as too thin.
- Low-evidence accepted sources are flagged in the UI as draft-friendly / low evidence so the user knows to review the generated draft or rerun with stronger source text.

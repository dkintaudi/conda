# Fill Report — v01.20  (live, against the real inlined Autogenerate logic)

Method: the actual Autogenerate.html parser, `buildData`, and the inlined
PizZip + SheetJS + docxtemplater were run headlessly against the two real
ground-truth Profiler exports in 07_Sample_Inputs. Counts and coverage below are
from live runs, and the DOCX outputs were re-opened and scanned for any leftover
`{placeholder}`.

## TRT roll-up counts (derived from the Profiler triggered-artifact list)
| Sample | Band / V-C | doc_count | pmo_count | tarc_count |
|---|---|---|---|---|
| Copilot Pilot | Mini / 39 | 30 | 17 | 13 |
| AB 2123 PFL  | Targeted / 87 | 36 | 17 | 19 |

`tarc_count` includes routed owners ("TARC → Development Team",
"TARC → TGD — Procurement"). Filled only when the template declares the placeholder
and it is still empty; explicit TRT-prose figures win.

## Per-template coverage (vs the Template-Map fill model)
| Template | Fields (scalar+loop-child) | Covered | Gaps |
|---|---|---|---|
| 01_Project_Charter | 26 | 25 | 1 (funding_source) |
| 03_Stakeholder_Register | 9 | 9 | 0 |
| 04_Engagement_Matrix | 11 | 11 | 0 |
| 05_CRAID_Log | 26 | 26 | 0 |
| 08_TRT_Recommendation | 24 | 24 | 0 |
| Governance_Management_Plan | 24 | 24 | 0 |
| Project_Charter_Full | 41 | 37 | 4 (charter_authorization, funding_sources, sponsor_approval_text, sponsor_signature) |
| Project_Charter_Mini | 29 | 29 | 0 |
| Project_Management_Plan_Mini | 37 | 37 | 0 |
| Project_Management_Plan | 31 | 31 | 0 |

Remaining gaps = 5, and all 5 are the true-manual fields (signatures + funding source).
Every other field across all 10 templates auto-fills from Profiler or TRT.

## Live render checks
- TRT Recommendation (both samples): 0 leftover placeholders; rendered DOCX contains the
  count values above.
- CRAID Log: renders cleanly; empty {#issues} loop leaves no stray braces.
- Project_Charter_Full: 0 leftover; [PM TO COMPLETE] markers present for the manual fields.

## Scale
- 50,000 randomized count-derivation runs — 0 mismatches.
- 120 real DOCX renders (10 templates × 2 exports × 6 reps) — 0 errors, 0 leftover placeholders.

## Definition of done
Copilot/PM touches only signatures + funding source. Everything else auto-fills.  ✔

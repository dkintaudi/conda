# Template Wiring & Fill-Coverage Report — v01.19f
Generated against the 10 templates in 02_Templates_and_Reference.zip, scored vs the
Profiler structured export + Profiler narrative/intake fields + TRT-Recommendation-derived
fields + loop-row synthesis.

## Headline
- Templates analyzed: 10
- Total scalar placeholders (loop markers excluded): 243
- Auto-fillable (Profiler / TRT / loop-row / boilerplate): 234  (~96%)
- Gaps falling to Copilot/PM: 9 — but only ~5 are TRUE manual fields.

## Per-template
| Template | Fields | Covered | Gaps |
|---|---|---|---|
| 01_Project_Charter_TEMPLATE.docx | 23 | 22 | 1 |
| 03_Stakeholder_Register_TEMPLATE.docx | 9 | 9 | 0 |
| 04_Engagement_Matrix_TEMPLATE.docx | 11 | 11 | 0 |
| 05_CRAID_Log_TEMPLATE.docx | 17 | 16 | 1 |
| 08_TRT_Recommendation_TEMPLATE.docx | 24 | 21 | 3 |
| Governance_Management_Plan_TEMPLATE.docx | 23 | 23 | 0 |
| Project_Charter_Full_TEMPLATE.docx | 39 | 35 | 4 |
| Project_Charter_Mini_TEMPLATE.docx | 29 | 29 | 0 |
| Project_Management_Plan_Mini_TEMPLATE.docx | 37 | 37 | 0 |
| Project_Management_Plan_TEMPLATE.docx | 31 | 31 | 0 |
| **TOTAL** | **243** | **234** | **9** |

## The 9 gaps, triaged
### TRUE manual — leave to human, Copilot should NOT fill (5)
- Project_Charter_Full: sponsor_signature, sponsor_approval_text, charter_authorization, funding_sources
- 01_Project_Charter: funding_source

### Derivable — SHOULD be wired, currently a miss (3)
- 08_TRT_Recommendation: doc_count, pmo_count, tarc_count
  → These are counts of the artifacts/owners the Profiler ALREADY triggers. The tool has
    the triggered list; it just needs to count by doc, by PMO-owned, by TARC. Pure wiring.

### False gap — correctly empty (1)
- 05_CRAID_Log: issue  → loop-child of {#issues}. A new project has no issues at charter
  time, so an empty issues loop is correct. Add 'issue' to the loop-children set so it
  stops reporting as a scalar gap.

## Next-chat build tasks (in priority order)
1. Wire doc_count / pmo_count / tarc_count from the Profiler triggered-artifact list (closes 3 gaps).
2. Add 'issue' (and audit all loop-children) to the gap reporter's loop-aware set (closes 1 false gap).
3. Confirm the 5 true-manual fields render as [PM TO COMPLETE] / signature lines, never auto-filled.
4. Run the per-template fill test at scale (50k+) using a REAL Profiler export + a REAL TRT deck
   (Copilot Pilot + AB 2123 are the two known-good ground-truth inputs), and confirm the live
   Autogenerate produces the same 234/243 coverage the static analysis predicts.
5. Target end-state: Copilot touches only signatures + funding source. Everything else auto-fills.

## Method notes for the build
- Placeholder syntax in templates: {field}, {#loop}...{/loop}. Loop CHILDREN (row columns)
  must be treated as covered when their loop has rows — NOT as scalar gaps (this was the
  v01.12 gap-reporter fix; keep it).
- Fill order: Profiler struct → Profiler narrative/intake → TRT-derived (labeled "Source: TRT
  Recommendation") → loop-row synthesis → boilerplate (sp_*/gov_*) → [PM TO COMPLETE].
- Field source sets are in /tmp/coverage.py (PROFILER_STRUCT, PROFILER_NARRATIVE, TRT_DERIVED,
  LOOP_CHILDREN, BOILERPLATE, MANUAL) — reuse/refine these.

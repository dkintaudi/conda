# ESPMO Governance Toolset — v01.2 EDD Visual Polish

This package keeps the existing self-contained tool behavior intact and applies a visual consistency pass so the tools feel more aligned to an EDD / State-of-California internal governance surface.

## What changed
- Added a shared EDD-inspired visual treatment across the four self-contained tools.
- Standardized the current package label to **v01.2** in visible headings/titles and package naming.
- Added rounded cards, cleaner spacing, stronger blue/teal/gold hierarchy, and clearer action buttons.
- Preserved the local-only/no-upload posture.

## What did not change
- No JavaScript application logic was modified.
- No scoring, tiering, rule, export, parsing, fill, template, or download features were changed.
- The historical changelog notes remain in the package for traceability.

## Tools
- `01_Tools_Self_Contained/Project-Profiler.html`
- `01_Tools_Self_Contained/Autogenerate.html`
- `01_Tools_Self_Contained/Rules-Admin.html`
- `01_Tools_Self_Contained/Obligation-Explorer.html`

To use a tool, open its `.html` file directly in a web browser — no install,
server, or internet connection required.

## Where things are
- **This file** is the current entry point for the v01.2 release.
- `00_START_HERE_User_Auditor_Guide.docx` — auditor / user guide.
- `00_RULES_TEAM_WALKTHROUGH.md` — rules team walkthrough.
- `01_Tools_Self_Contained/` — the four self-contained HTML tools (open any directly).
- `02_Templates_and_Reference/` — blank templates and reference workbooks.
- `03_Filled_Examples/` — worked/filled example documents.
- `04_QA_Checks/` — template validator (`validate_templates.py`, requires Python 3).
- `05_Reference_Workbooks/` — rules workbooks and narrative-rules JSON.
- `06_Reference_Diagrams/` — reference diagrams.
- `07_Sample_Inputs/` — sample Profiler exports and decks.
- `PACKAGE-MANIFEST.sha256` — SHA-256 integrity manifest for every file.
- `_archive/` — historical changelogs and superseded notes from the
  v01.04 → v01.20 arc, kept for traceability only (not needed to use the toolset).

Everything is laid out as plain folders — no nested zips to extract. Just unzip
the package once and open what you need.

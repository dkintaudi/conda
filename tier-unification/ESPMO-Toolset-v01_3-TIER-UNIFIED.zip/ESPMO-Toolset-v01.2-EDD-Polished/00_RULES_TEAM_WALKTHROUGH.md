# ESPMO Governance Rules Manager — Team Walkthrough

Use this guide to review governance rules through the structured Rules Manager view. The screen is organized by business rule area instead of technical configuration terms.

## Primary review sections

1. **Load & Publish** — load the approved Rules Workbook and confirm the rule version.
2. **Scoring Model** — shows how answers translate into governance tier, value, and complexity.
3. **Complexity Factors** — shows which questions increase SIMM complexity.
4. **Questions** — shows the intake questions the project team answers.
5. **Document Triggers** — shows why a document is recommended.
6. **Engagement Matrix** — shows who leads, supports, reviews, or is informed by deliverable.
7. **Ownership and Routing** — shows PMO-assisted versus routed/owned items.
8. **Template Mapping** — shows which approved Word template is used by the Auto Generator.

## Technical review area

The **Advanced Data** section is intended for technical validation and export. Standard reviews should use the structured sections above.

## Review note

Reviewing a rule does not change the Profiler or Auto Generator. Updated outputs are created only when an owner publishes the selected outputs.

## Scoring workbook review tabs

The reference Rules Workbook includes manager-review tabs that show the scoring model in business terms:

- **Score_Guide** — summarizes how SIMM complexity, value, and the value-complexity read roll up.
- **SIMM_Score_Responses** — lists each SIMM business and technical complexity factor, the related intake question, each response option, and the score applied.
- **Value_Score_Responses** — lists each value-driver question, each response option, the points applied, and the maximum total value score.

Use these tabs when reviewing scoring rationale with managers or project stakeholders. Use the structured Rules Manager sections for configuration review and the workbook tabs for scoring traceability.

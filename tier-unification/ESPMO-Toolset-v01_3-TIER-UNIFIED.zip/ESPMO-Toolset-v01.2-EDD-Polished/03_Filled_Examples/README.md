# Filled Examples

These files demonstrate expected output quality and review-ready package content.

Included examples:
- **Charter_FILLED_example.docx** — filled charter example.
- **CRAID_Log_FILLED_example.docx** — filled CRAID log example.
- **TRT_Template_FILLED_example.docx** — filled TRT template example.
- **ITW0001081_TRT_Recommendation_ENRICHED.docx** — enriched TRT recommendation example.
- **DEMO_Schedule_STAMPED.xlsx** — stamped demo schedule workbook preserved from the incoming package and filed here as a user-facing example.


Schedule note: the generated schedule includes a “Review and Revise Engagement Matrix” task. The Profiler provides the suggested Engagement Matrix; the schedule keeps the PM review/revision accountability step.

# Sample Inputs — ground-truth Profiler exports for fill testing

Two REAL Profiler exports, the known-good calibration pair. Use these to verify Autogenerate
fills correctly and to confirm the Mini vs Full depth call on live data.

| File | Project | Value | avgCx | V-C | Band | Depth |
|---|---|---|---|---|---|---|
| SAMPLE_Profiler-Export_Copilot-Pilot_MINI_VC39.xlsx | GitHub Copilot Pilot (ITW0001081) | 45 | 2.38 | 39 | Mini | Mini |
| SAMPLE_Profiler-Export_AB2123-PFL_TARGETED_VC87.xlsx | AB 2123 PFL Expansion | 95 | 3.24 | 87 | Targeted | Full |

These span the band range (Mini ↔ Targeted) so a fill test exercises both the Mini and Full
template paths from real data.

## TRT DECK — not included (rotated out of the sandbox)
The real Copilot Pilot TRT/DCT deck (ITW0001081 ... Pilot.pptx) was uploaded in an earlier
session and is no longer on disk here, so it could not be bundled. For the TRT-parse fill test
in the next chat, re-upload either:
  - the GitHub Copilot Pilot DCT/TRT deck (.pptx), or
  - the Windows Hello for Business intake email (CHG0032000) — both are known to pass the
    v01.18+ business-case evidence gate and exercise the TRT-derived fill path.

## TRT / Intake source documents (added — for the narrative/TRT fill path)
| File | What it is | Use |
|---|---|---|
| SAMPLE_TRT-Deck_Copilot-Pilot.pptx | Real GitHub Copilot Pilot DCT/TRT deck | TRT-parse fill test (pairs with the Copilot export above) |
| SAMPLE_Intake-Doc_Copilot-Pilot.docx | Copilot Pilot intake write-up (Word) | Word/business-case gate + TRT-derived fill |
| SAMPLE_Intake-Doc_C2009476_Replace-Project-Online.docx | Real intake: replace MS Project Online before Sep 2026 | Fresh end-to-end test case (un-scored — run through Profiler then Autogenerate) |

Now the sample set covers BOTH fill paths:
- structured fill  -> the two Profiler exports (Copilot Pilot = Mini, AB 2123 = Targeted)
- narrative/TRT fill -> the Copilot deck + the two intake docs
